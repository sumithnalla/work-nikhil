import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import SnakeGame from "@/pages/SnakeGame";
import MemoryGame from "@/pages/MemoryGame";
import TicTacToeGame from "@/pages/TicTacToeGame";
import WordScrambleGame from "@/pages/WordScrambleGame";
import MathQuizGame from "@/pages/MathQuizGame";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/snake" component={SnakeGame} />
        <Route path="/memory" component={MemoryGame} />
        <Route path="/tictactoe" component={TicTacToeGame} />
        <Route path="/wordscramble" component={WordScrambleGame} />
        <Route path="/mathquiz" component={MathQuizGame} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="page-load">
          <div className="bg-animation"></div>
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
