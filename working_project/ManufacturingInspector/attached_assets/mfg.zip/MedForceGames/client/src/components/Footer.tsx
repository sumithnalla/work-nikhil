export default function Footer() {
  return (
    <footer className="mt-16 py-8 border-t border-neon-purple/30 bg-black/50">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          {/* About Section */}
          <div>
            <h3 className="font-orbitron font-bold text-xl gradient-text mb-4">About MedForce Games</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              MedForce Games brings classic arcade experiences to life with futuristic neon styling. 
              Designed for gamers who appreciate both nostalgia and cutting-edge visual effects.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="font-orbitron font-bold text-xl gradient-text mb-4">Quick Links</h3>
            <div className="space-y-2">
              <div className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Privacy Policy</div>
              <div className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Terms of Service</div>
              <div className="text-gray-400 hover:text-neon-blue transition-colors cursor-pointer">Game Rules</div>
            </div>
          </div>
          
          {/* Contact */}
          <div>
            <h3 className="font-orbitron font-bold text-xl gradient-text mb-4">Contact</h3>
            <div className="space-y-2">
              <div className="text-gray-400">Email: info@medforce.games</div>
              <div className="text-gray-400">Support: support@medforce.games</div>
              <div className="text-neon-blue font-semibold">24/7 Gaming Support</div>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-gray-700 text-center">
          <p className="text-gray-400 text-sm">
            © 2024 MedForce Games. All rights reserved. | Made for True Gamers
          </p>
        </div>
      </div>
    </footer>
  );
}