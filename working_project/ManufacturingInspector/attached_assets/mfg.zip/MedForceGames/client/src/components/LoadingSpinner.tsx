interface LoadingSpinnerProps {
  message?: string;
}

export default function LoadingSpinner({ message = "Loading Game..." }: LoadingSpinnerProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[400px] space-y-6">
      <div className="relative">
        {/* Outer ring */}
        <div className="w-16 h-16 border-4 border-neon-purple/30 border-t-neon-purple rounded-full animate-spin"></div>
        {/* Inner ring */}
        <div className="absolute top-2 left-2 w-12 h-12 border-4 border-neon-blue/30 border-t-neon-blue rounded-full animate-spin animate-reverse"></div>
        {/* Center dot */}
        <div className="absolute top-6 left-6 w-4 h-4 bg-gradient-to-r from-neon-purple to-neon-blue rounded-full pulse-glow"></div>
      </div>
      
      <div className="text-center">
        <div className="font-orbitron text-xl gradient-text neon-glow mb-2">{message}</div>
        <div className="flex space-x-1">
          <div className="w-2 h-2 bg-neon-purple rounded-full animate-pulse" style={{ animationDelay: '0ms' }}></div>
          <div className="w-2 h-2 bg-neon-blue rounded-full animate-pulse" style={{ animationDelay: '200ms' }}></div>
          <div className="w-2 h-2 bg-neon-purple rounded-full animate-pulse" style={{ animationDelay: '400ms' }}></div>
        </div>
      </div>
    </div>
  );
}