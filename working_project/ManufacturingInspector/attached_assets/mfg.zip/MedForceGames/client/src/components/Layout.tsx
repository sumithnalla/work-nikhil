import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMusic } from "@/hooks/useMusic";
import { Volume2, VolumeX } from "lucide-react";
import Footer from "./Footer";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isMuted, toggleMute, playSound } = useMusic();

  const navItems = [
    { path: "/", label: "HOME" },
    { path: "/snake", label: "SNAKE" },
    { path: "/memory", label: "MEMORY" },
    { path: "/tictactoe", label: "TIC-TAC-TOE" },
    { path: "/wordscramble", label: "WORD SCRAMBLE" },
    { path: "/mathquiz", label: "MATH QUIZ" },
  ];

  const isActive = (path: string) => {
    if (path === "/") return location === "/";
    return location.startsWith(path);
  };

  return (
    <div className="min-h-screen bg-dark-bg text-white">
      {/* Fixed Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-neon-purple/30">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <div className="font-orbitron font-bold text-xl gradient-text neon-glow cursor-pointer">
                MedForce
              </div>
            </Link>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex space-x-8 items-center">
              {navItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <span 
                    className={`nav-link ${isActive(item.path) ? "active" : ""}`}
                    onClick={() => playSound('click')}
                  >
                    {item.label}
                  </span>
                </Link>
              ))}
              
              {/* Music Toggle */}
              <button
                onClick={() => {
                  playSound('click');
                  toggleMute();
                }}
                className="ml-4 p-2 rounded-lg border border-gray-500 text-white hover:border-neon-blue transition-colors"
                title={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
              </button>
            </div>
            
            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
              </svg>
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-black/95">
          <div className="flex flex-col items-center justify-center h-full space-y-8 font-orbitron text-lg">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <span
                  className={`nav-link ${isActive(item.path) ? "active" : ""}`}
                  onClick={() => {
                    playSound('click');
                    setMobileMenuOpen(false);
                  }}
                >
                  {item.label}
                </span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="pt-20 min-h-screen">
        {children}
      </main>
      
      <Footer />
    </div>
  );
}
