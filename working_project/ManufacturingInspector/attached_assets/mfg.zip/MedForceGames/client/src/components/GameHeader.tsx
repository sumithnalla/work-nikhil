import { useLocation } from "wouter";
import { useMusic } from "@/hooks/useMusic";
import { Home, RotateCcw } from "lucide-react";

interface GameHeaderProps {
  title: string;
  icon: React.ReactNode;
  score: number;
  level: number;
  onRestart: () => void;
  showQuit?: boolean;
}

export default function GameHeader({ 
  title, 
  icon, 
  score, 
  level, 
  onRestart, 
  showQuit = true 
}: GameHeaderProps) {
  const [, setLocation] = useLocation();
  const { playSound } = useMusic();

  const handleQuit = () => {
    playSound('click');
    setLocation('/');
  };

  const handleRestart = () => {
    playSound('click');
    onRestart();
  };

  return (
    <div className="flex items-center justify-between mb-8 p-4 bg-dark-secondary/50 rounded-lg border border-neon-purple/30">
      <div className="flex items-center space-x-4">
        <div className="w-12 h-12 gradient-bg rounded-lg flex items-center justify-center">
          {icon}
        </div>
        <div>
          <h1 className="font-orbitron font-bold text-2xl gradient-text neon-glow">{title}</h1>
          <div className="flex items-center space-x-4 text-sm">
            <span className="text-neon-green">Score: {score}</span>
            <span className="text-neon-blue">Level: {level}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        <button
          onClick={handleRestart}
          className="p-2 rounded-lg border border-gray-500 text-white hover:border-neon-blue transition-colors"
          title="Restart Game"
        >
          <RotateCcw size={20} />
        </button>
        {showQuit && (
          <button
            onClick={handleQuit}
            className="p-2 rounded-lg border border-gray-500 text-white hover:border-neon-purple transition-colors"
            title="Return to Home"
          >
            <Home size={20} />
          </button>
        )}
      </div>
    </div>
  );
}