interface GameCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick: () => void;
}

export default function GameCard({ title, description, icon, onClick }: GameCardProps) {
  return (
    <div className="game-card" onClick={onClick}>
      <div className="text-center">
        <div className="w-16 h-16 mx-auto mb-4 gradient-bg rounded-lg flex items-center justify-center">
          {icon}
        </div>
        <h3 className="font-orbitron font-bold text-xl mb-2 text-neon-blue">{title}</h3>
        <p className="text-gray-400 text-sm">{description}</p>
      </div>
    </div>
  );
}
