import { useState } from "react";
import { useLocation } from "wouter";

type Player = "X" | "O" | null;
type Board = Player[];

export default function TicTacToeGame() {
  const [, setLocation] = useLocation();
  const [board, setBoard] = useState<Board>(Array(9).fill(null));
  const [currentPlayer, setCurrentPlayer] = useState<"X" | "O">("X");
  const [gameActive, setGameActive] = useState(true);
  const [winner, setWinner] = useState<Player>(null);
  const [isDraw, setIsDraw] = useState(false);

  const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
    [0, 4, 8], [2, 4, 6], // diagonals
  ];

  const checkWinner = (gameBoard: Board): Player => {
    for (const pattern of winPatterns) {
      const [a, b, c] = pattern;
      if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
        return gameBoard[a];
      }
    }
    return null;
  };

  const handleCellClick = (index: number) => {
    if (board[index] || !gameActive) return;

    const newBoard = [...board];
    newBoard[index] = currentPlayer;
    setBoard(newBoard);

    const gameWinner = checkWinner(newBoard);
    if (gameWinner) {
      setWinner(gameWinner);
      setGameActive(false);
    } else if (newBoard.every((cell) => cell !== null)) {
      setIsDraw(true);
      setGameActive(false);
    } else {
      setCurrentPlayer(currentPlayer === "X" ? "O" : "X");
    }
  };

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setCurrentPlayer("X");
    setGameActive(true);
    setWinner(null);
    setIsDraw(false);
  };

  const getStatusMessage = () => {
    if (winner) return `Player ${winner} Wins!`;
    if (isDraw) return "It's a Draw!";
    return `Player ${currentPlayer}'s Turn`;
  };

  const getStatusColor = () => {
    if (winner) return "text-neon-green";
    if (isDraw) return "text-yellow-400";
    return "text-neon-blue";
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6">
      <div className="text-center mb-8 fade-in">
        <h2 className="font-orbitron font-bold text-4xl gradient-text neon-glow mb-4">
          Tic-Tac-Toe
        </h2>
        <p className="text-gray-400 mb-4">Get three in a row to win</p>
        <div className={`font-bold text-xl mb-4 ${getStatusColor()}`}>
          {getStatusMessage()}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-6">
        {board.map((cell, index) => (
          <div
            key={index}
            className="tic-cell flex items-center justify-center text-3xl font-bold cursor-pointer"
            onClick={() => handleCellClick(index)}
            style={{
              color: cell === "X" ? "#BC00FF" : cell === "O" ? "#00F0FF" : "transparent",
            }}
          >
            {cell}
          </div>
        ))}
      </div>

      <div className="flex space-x-4">
        <button onClick={resetGame} className="btn-neon px-6 py-3 rounded-lg">
          New Game
        </button>
        <button
          onClick={() => setLocation("/")}
          className="border border-gray-500 px-6 py-3 rounded-lg font-orbitron text-white hover:border-neon-blue transition-colors"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}
