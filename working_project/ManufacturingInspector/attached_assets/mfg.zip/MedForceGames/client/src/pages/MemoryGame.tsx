import { useState, useEffect } from "react";
import { useLocation } from "wouter";

interface Card {
  id: number;
  symbol: string;
  isFlipped: boolean;
  isMatched: boolean;
}

export default function MemoryGame() {
  const [, setLocation] = useLocation();
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [matchedPairs, setMatchedPairs] = useState(0);
  const [moves, setMoves] = useState(0);
  const [canFlip, setCanFlip] = useState(true);

  const symbols = ["🌟", "⚡", "🔥", "💎", "🎯", "🚀", "⭐", "💫"];

  const initializeGame = () => {
    const gameCards = [...symbols, ...symbols]
      .sort(() => Math.random() - 0.5)
      .map((symbol, index) => ({
        id: index,
        symbol,
        isFlipped: false,
        isMatched: false,
      }));

    setCards(gameCards);
    setFlippedCards([]);
    setMatchedPairs(0);
    setMoves(0);
    setCanFlip(true);
  };

  const handleCardClick = (cardId: number) => {
    if (!canFlip) return;
    if (flippedCards.includes(cardId)) return;
    if (cards[cardId].isMatched) return;

    const newFlippedCards = [...flippedCards, cardId];
    setFlippedCards(newFlippedCards);

    setCards((prevCards) =>
      prevCards.map((card) =>
        card.id === cardId ? { ...card, isFlipped: true } : card
      )
    );

    if (newFlippedCards.length === 2) {
      setCanFlip(false);
      setMoves((prev) => prev + 1);

      setTimeout(() => {
        checkForMatch(newFlippedCards);
      }, 1000);
    }
  };

  const checkForMatch = (flippedCardIds: number[]) => {
    const [firstId, secondId] = flippedCardIds;
    const firstCard = cards[firstId];
    const secondCard = cards[secondId];

    if (firstCard.symbol === secondCard.symbol) {
      setCards((prevCards) =>
        prevCards.map((card) =>
          card.id === firstId || card.id === secondId
            ? { ...card, isMatched: true }
            : card
        )
      );
      setMatchedPairs((prev) => prev + 1);
    } else {
      setCards((prevCards) =>
        prevCards.map((card) =>
          card.id === firstId || card.id === secondId
            ? { ...card, isFlipped: false }
            : card
        )
      );
    }

    setFlippedCards([]);
    setCanFlip(true);
  };

  useEffect(() => {
    initializeGame();
  }, []);

  useEffect(() => {
    if (matchedPairs === 8) {
      setTimeout(() => {
        alert(`Congratulations! You won in ${moves} moves!`);
      }, 500);
    }
  }, [matchedPairs, moves]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6">
      <div className="text-center mb-8 fade-in">
        <h2 className="font-orbitron font-bold text-4xl gradient-text neon-glow mb-4">
          Memory Game
        </h2>
        <p className="text-gray-400 mb-4">Match all the pairs to win</p>
        <div className="flex items-center justify-center space-x-8 mb-4">
          <div className="text-neon-green">
            Moves: <span className="font-bold">{moves}</span>
          </div>
          <div className="text-neon-blue">
            Pairs: <span className="font-bold">{matchedPairs}/8</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 mb-6">
        {cards.map((card) => (
          <div
            key={card.id}
            className={`memory-card flex items-center justify-center text-2xl ${
              card.isFlipped || card.isMatched ? "flipped" : ""
            }`}
            onClick={() => handleCardClick(card.id)}
          >
            {card.isFlipped || card.isMatched ? card.symbol : ""}
          </div>
        ))}
      </div>

      <div className="flex space-x-4">
        <button onClick={initializeGame} className="btn-neon px-6 py-3 rounded-lg">
          New Game
        </button>
        <button
          onClick={() => setLocation("/")}
          className="border border-gray-500 px-6 py-3 rounded-lg font-orbitron text-white hover:border-neon-blue transition-colors"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}
