import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";

interface Question {
  question: string;
  answer: number;
  options: number[];
}

interface GameState {
  score: number;
  questionNumber: number;
  totalQuestions: number;
  timer: number;
  gameActive: boolean;
  currentQuestion: Question | null;
  feedback: string;
  feedbackColor: string;
}

export default function MathQuizGame() {
  const [, setLocation] = useLocation();
  const timerRef = useRef<NodeJS.Timeout>();
  const [gameState, setGameState] = useState<GameState>({
    score: 0,
    questionNumber: 0,
    totalQuestions: 10,
    timer: 30,
    gameActive: false,
    currentQuestion: null,
    feedback: "",
    feedbackColor: "",
  });

  const generateQuestion = (): Question => {
    const a = Math.floor(Math.random() * 20) + 1;
    const b = Math.floor(Math.random() * 20) + 1;
    const operations = ["+", "-", "*"];
    const operation = operations[Math.floor(Math.random() * operations.length)];

    let question: string;
    let answer: number;

    switch (operation) {
      case "+":
        question = `${a} + ${b}`;
        answer = a + b;
        break;
      case "-":
        question = `${a} - ${b}`;
        answer = a - b;
        break;
      case "*":
        question = `${a} × ${b}`;
        answer = a * b;
        break;
      default:
        question = `${a} + ${b}`;
        answer = a + b;
    }

    // Generate options
    const options = [answer];
    while (options.length < 4) {
      const wrongAnswer = answer + Math.floor(Math.random() * 20) - 10;
      if (!options.includes(wrongAnswer) && wrongAnswer >= 0) {
        options.push(wrongAnswer);
      }
    }

    return {
      question,
      answer,
      options: options.sort(() => Math.random() - 0.5),
    };
  };

  const startQuiz = () => {
    setGameState({
      score: 0,
      questionNumber: 0,
      totalQuestions: 10,
      timer: 30,
      gameActive: true,
      currentQuestion: null,
      feedback: "",
      feedbackColor: "",
    });
    nextQuestion();
    startTimer();
  };

  const nextQuestion = () => {
    setGameState((prev) => {
      if (prev.questionNumber >= prev.totalQuestions) {
        endQuiz();
        return prev;
      }

      return {
        ...prev,
        questionNumber: prev.questionNumber + 1,
        currentQuestion: generateQuestion(),
        feedback: "",
        feedbackColor: "",
      };
    });
  };

  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setGameState((prev) => {
        if (prev.timer <= 1) {
          endQuiz();
          return prev;
        }
        return { ...prev, timer: prev.timer - 1 };
      });
    }, 1000);
  };

  const endQuiz = () => {
    setGameState((prev) => ({ ...prev, gameActive: false }));
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setTimeout(() => {
      alert(`Quiz Complete! Your score: ${gameState.score}/${gameState.totalQuestions * 10}`);
    }, 500);
  };

  const checkAnswer = (selectedAnswer: number) => {
    if (!gameState.gameActive || !gameState.currentQuestion) return;

    if (selectedAnswer === gameState.currentQuestion.answer) {
      setGameState((prev) => ({
        ...prev,
        score: prev.score + 10,
        feedback: "Correct!",
        feedbackColor: "text-neon-green",
      }));
    } else {
      setGameState((prev) => ({
        ...prev,
        feedback: "Wrong!",
        feedbackColor: "text-red-400",
      }));
    }

    setTimeout(() => {
      nextQuestion();
    }, 1500);
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6">
      <div className="text-center mb-8 fade-in">
        <h2 className="font-orbitron font-bold text-4xl gradient-text neon-glow mb-4">
          Math Quiz
        </h2>
        <p className="text-gray-400 mb-4">Solve the math problems as fast as you can</p>
        <div className="flex items-center justify-center space-x-8 mb-4">
          <div className="text-neon-green">
            Score: <span className="font-bold">{gameState.score}</span>
          </div>
          <div className="text-neon-blue">
            Question: <span className="font-bold">{gameState.questionNumber}/{gameState.totalQuestions}</span>
          </div>
          <div className="text-neon-purple">
            Time: <span className="font-bold">{gameState.timer}s</span>
          </div>
        </div>
      </div>

      <div className="text-center mb-8 max-w-md">
        <div className="text-4xl font-orbitron mb-6 text-white">
          {gameState.currentQuestion ? gameState.currentQuestion.question : "Click Start to begin"}
        </div>
        
        {gameState.currentQuestion && (
          <div className="grid grid-cols-2 gap-4">
            {gameState.currentQuestion.options.map((option, index) => (
              <button
                key={index}
                onClick={() => checkAnswer(option)}
                className="quiz-option font-orbitron"
                disabled={!gameState.gameActive}
              >
                {option}
              </button>
            ))}
          </div>
        )}
        
        <div className={`text-lg font-bold mt-4 ${gameState.feedbackColor}`}>
          {gameState.feedback}
        </div>
      </div>

      <div className="flex space-x-4">
        <button onClick={startQuiz} className="btn-neon px-6 py-3 rounded-lg">
          Start Quiz
        </button>
        <button
          onClick={() => setLocation("/")}
          className="border border-gray-500 px-6 py-3 rounded-lg font-orbitron text-white hover:border-neon-blue transition-colors"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}
