import { useLocation } from "wouter";
import GameCard from "@/components/GameCard";
import { useMusic } from "@/hooks/useMusic";
import { Gamepad2, Brain, Grid3X3, Type, Calculator } from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const { playSound } = useMusic();

  const games = [
    {
      title: "Snake",
      description: "Navigate the neon maze - 5 difficulty levels",
      path: "/snake",
      icon: <Gamepad2 className="w-8 h-8 text-white" />,
    },
    {
      title: "Memory Match",
      description: "Test your memory with glowing cards",
      path: "/memory",
      icon: <Brain className="w-8 h-8 text-white" />,
    },
    {
      title: "Tic-Tac-Toe",
      description: "Strategic battles against smart AI",
      path: "/tictactoe",
      icon: <Grid3X3 className="w-8 h-8 text-white" />,
    },
    {
      title: "Word Scramble",
      description: "Unscramble futuristic code words",
      path: "/wordscramble",
      icon: <Type className="w-8 h-8 text-white" />,
    },
    {
      title: "Math Quiz",
      description: "Calculate your way to victory",
      path: "/mathquiz",
      icon: <Calculator className="w-8 h-8 text-white" />,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 relative">
      <div className="particle-bg"></div>
      <div className="text-center fade-in mb-16">
        {/* Centered Glowing Logo */}
        <h1 className="font-orbitron font-black text-6xl md:text-8xl gradient-text neon-glow pulse-glow main-logo mb-4">
          MedForce Games
        </h1>
        
        {/* Tagline */}
        <p className="font-inter text-xl md:text-2xl text-gray-300 mb-12 tracking-wide">
          Made For True Gamers
        </p>
        
        {/* Browse Games Button */}
        <button 
          className="btn-neon px-8 py-4 rounded-lg text-lg neon-glow mb-16"
          onClick={() => {
            playSound('click');
            document.getElementById('games-section')?.scrollIntoView({ 
              behavior: 'smooth' 
            });
          }}
        >
          Browse Games
        </button>
      </div>
      
      {/* Game Grid */}
      <section id="games-section" className="w-full max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {games.map((game) => (
            <GameCard
              key={game.title}
              title={game.title}
              description={game.description}
              icon={game.icon}
              onClick={() => {
                playSound('click');
                setLocation(game.path);
              }}
            />
          ))}
        </div>
      </section>
    </div>
  );
}
