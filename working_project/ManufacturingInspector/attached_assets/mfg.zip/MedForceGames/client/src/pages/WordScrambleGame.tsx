import { useState, useEffect } from "react";
import { useLocation } from "wouter";

interface GameState {
  currentWord: string;
  scrambledWord: string;
  score: number;
  level: number;
  feedback: string;
  feedbackColor: string;
}

export default function WordScrambleGame() {
  const [, setLocation] = useLocation();
  const [gameState, setGameState] = useState<GameState>({
    currentWord: "",
    scrambledWord: "CLICK START",
    score: 0,
    level: 1,
    feedback: "",
    feedbackColor: "",
  });
  const [userInput, setUserInput] = useState("");

  const words = [
    "JAVASCRIPT",
    "COMPUTER",
    "PROGRAMMING",
    "ALGORITHM",
    "FUNCTION",
    "VARIABLE",
    "OBJECT",
    "ARRAY",
    "BOOLEAN",
    "STRING",
    "FRAMEWORK",
    "LIBRARY",
    "DATABASE",
    "INTERFACE",
    "COMPONENT",
  ];

  const scrambleWord = (word: string): string => {
    return word.split("").sort(() => Math.random() - 0.5).join("");
  };

  const nextWord = () => {
    const randomWord = words[Math.floor(Math.random() * words.length)];
    const scrambled = scrambleWord(randomWord);
    
    setGameState((prev) => ({
      ...prev,
      currentWord: randomWord,
      scrambledWord: scrambled,
      feedback: "",
      feedbackColor: "",
    }));
    setUserInput("");
  };

  const submitWord = () => {
    const guess = userInput.toUpperCase().trim();
    
    if (guess === gameState.currentWord) {
      const points = gameState.level * 10;
      setGameState((prev) => ({
        ...prev,
        score: prev.score + points,
        level: prev.level + 1,
        feedback: `Correct! +${points} points`,
        feedbackColor: "text-neon-green",
      }));
      
      setTimeout(() => {
        nextWord();
      }, 1500);
    } else {
      setGameState((prev) => ({
        ...prev,
        feedback: "Try again!",
        feedbackColor: "text-red-400",
      }));
      
      setTimeout(() => {
        setGameState((prev) => ({
          ...prev,
          feedback: "",
          feedbackColor: "",
        }));
      }, 2000);
    }
  };

  const startNewGame = () => {
    setGameState({
      currentWord: "",
      scrambledWord: "",
      score: 0,
      level: 1,
      feedback: "",
      feedbackColor: "",
    });
    nextWord();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      submitWord();
    }
  };

  useEffect(() => {
    nextWord();
  }, []);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6">
      <div className="text-center mb-8 fade-in">
        <h2 className="font-orbitron font-bold text-4xl gradient-text neon-glow mb-4">
          Word Scramble
        </h2>
        <p className="text-gray-400 mb-4">Unscramble the letters to form a word</p>
        <div className="flex items-center justify-center space-x-8 mb-4">
          <div className="text-neon-green">
            Score: <span className="font-bold">{gameState.score}</span>
          </div>
          <div className="text-neon-blue">
            Level: <span className="font-bold">{gameState.level}</span>
          </div>
        </div>
      </div>

      <div className="text-center mb-8">
        <div className="text-3xl font-orbitron mb-4 text-neon-purple neon-glow">
          {gameState.scrambledWord}
        </div>
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Enter your guess..."
          className="bg-dark-secondary border-2 border-neon-blue rounded-lg px-4 py-2 text-white text-center text-xl font-orbitron w-64 mb-4 focus:outline-none focus:border-neon-purple transition-colors"
        />
        <div className={`text-lg font-bold mb-4 ${gameState.feedbackColor}`}>
          {gameState.feedback}
        </div>
      </div>

      <div className="flex space-x-4">
        <button onClick={submitWord} className="btn-neon px-6 py-3 rounded-lg">
          Submit
        </button>
        <button
          onClick={nextWord}
          className="border border-gray-500 px-6 py-3 rounded-lg font-orbitron text-white hover:border-neon-blue transition-colors"
        >
          Skip
        </button>
        <button
          onClick={startNewGame}
          className="border border-gray-500 px-6 py-3 rounded-lg font-orbitron text-white hover:border-neon-blue transition-colors"
        >
          New Game
        </button>
        <button
          onClick={() => setLocation("/")}
          className="border border-gray-500 px-6 py-3 rounded-lg font-orbitron text-white hover:border-neon-blue transition-colors"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}
