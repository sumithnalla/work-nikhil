import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { useLocalStorage } from "@/hooks/useLocalStorage";

interface Position {
  x: number;
  y: number;
}

interface GameState {
  snake: Position[];
  food: Position;
  direction: Position;
  score: number;
  gameRunning: boolean;
  gameOver: boolean;
}

const INITIAL_STATE: GameState = {
  snake: [{ x: 200, y: 200 }],
  food: { x: 100, y: 100 },
  direction: { x: 20, y: 0 },
  score: 0,
  gameRunning: false,
  gameOver: false,
};

const CANVAS_SIZE = 400;
const CELL_SIZE = 20;

export default function SnakeGame() {
  const [, setLocation] = useLocation();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameLoopRef = useRef<NodeJS.Timeout>();
  const [gameState, setGameState] = useState<GameState>(INITIAL_STATE);
  const [highScore, setHighScore] = useLocalStorage("snakeHighScore", 0);

  const generateFood = useCallback((): Position => {
    return {
      x: Math.floor(Math.random() * (CANVAS_SIZE / CELL_SIZE)) * CELL_SIZE,
      y: Math.floor(Math.random() * (CANVAS_SIZE / CELL_SIZE)) * CELL_SIZE,
    };
  }, []);

  const drawGame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Clear canvas
    ctx.fillStyle = "#1A1A1F";
    ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    // Draw snake
    ctx.fillStyle = "#00FF88";
    ctx.shadowColor = "#00FF88";
    ctx.shadowBlur = 10;
    gameState.snake.forEach((segment) => {
      ctx.fillRect(segment.x, segment.y, CELL_SIZE - 2, CELL_SIZE - 2);
    });

    // Draw food
    ctx.fillStyle = "#FF4444";
    ctx.shadowColor = "#FF4444";
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(
      gameState.food.x + CELL_SIZE / 2,
      gameState.food.y + CELL_SIZE / 2,
      CELL_SIZE / 2 - 2,
      0,
      2 * Math.PI
    );
    ctx.fill();

    ctx.shadowBlur = 0;
  }, [gameState.snake, gameState.food]);

  const moveSnake = useCallback(() => {
    if (!gameState.gameRunning || gameState.gameOver) return;

    setGameState((prevState) => {
      const head = { ...prevState.snake[0] };
      head.x += prevState.direction.x;
      head.y += prevState.direction.y;

      // Check wall collision
      if (head.x < 0 || head.x >= CANVAS_SIZE || head.y < 0 || head.y >= CANVAS_SIZE) {
        return { ...prevState, gameRunning: false, gameOver: true };
      }

      // Check self collision
      if (prevState.snake.some((segment) => segment.x === head.x && segment.y === head.y)) {
        return { ...prevState, gameRunning: false, gameOver: true };
      }

      const newSnake = [head, ...prevState.snake];
      let newFood = prevState.food;
      let newScore = prevState.score;

      // Check food collision
      if (head.x === prevState.food.x && head.y === prevState.food.y) {
        newScore += 10;
        newFood = generateFood();
      } else {
        newSnake.pop();
      }

      return {
        ...prevState,
        snake: newSnake,
        food: newFood,
        score: newScore,
      };
    });
  }, [gameState.gameRunning, gameState.gameOver, generateFood]);

  const handleKeyPress = useCallback((e: KeyboardEvent) => {
    if (!gameState.gameRunning) return;

    const key = e.key.toLowerCase();
    setGameState((prevState) => {
      let newDirection = { ...prevState.direction };

      if ((key === "arrowup" || key === "w") && prevState.direction.y === 0) {
        newDirection = { x: 0, y: -CELL_SIZE };
      } else if ((key === "arrowdown" || key === "s") && prevState.direction.y === 0) {
        newDirection = { x: 0, y: CELL_SIZE };
      } else if ((key === "arrowleft" || key === "a") && prevState.direction.x === 0) {
        newDirection = { x: -CELL_SIZE, y: 0 };
      } else if ((key === "arrowright" || key === "d") && prevState.direction.x === 0) {
        newDirection = { x: CELL_SIZE, y: 0 };
      }

      return { ...prevState, direction: newDirection };
    });
  }, [gameState.gameRunning]);

  const startGame = () => {
    setGameState({
      ...INITIAL_STATE,
      food: generateFood(),
      gameRunning: true,
    });
  };

  const stopGame = () => {
    if (gameLoopRef.current) {
      clearInterval(gameLoopRef.current);
    }
    if (gameState.score > highScore) {
      setHighScore(gameState.score);
    }
  };

  useEffect(() => {
    drawGame();
  }, [drawGame]);

  useEffect(() => {
    if (gameState.gameRunning && !gameState.gameOver) {
      gameLoopRef.current = setInterval(moveSnake, 150);
    } else {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
      }
      if (gameState.gameOver) {
        stopGame();
      }
    }

    return () => {
      if (gameLoopRef.current) {
        clearInterval(gameLoopRef.current);
      }
    };
  }, [gameState.gameRunning, gameState.gameOver, moveSnake]);

  useEffect(() => {
    document.addEventListener("keydown", handleKeyPress);
    return () => document.removeEventListener("keydown", handleKeyPress);
  }, [handleKeyPress]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6">
      <div className="text-center mb-8 fade-in">
        <h2 className="font-orbitron font-bold text-4xl gradient-text neon-glow mb-4">Snake Game</h2>
        <p className="text-gray-400 mb-4">Use arrow keys or WASD to control the snake</p>
        <div className="flex items-center justify-center space-x-8 mb-4">
          <div className="text-neon-green">
            Score: <span className="font-bold">{gameState.score}</span>
          </div>
          <div className="text-neon-blue">
            High Score: <span className="font-bold">{highScore}</span>
          </div>
        </div>
      </div>

      <div className="neon-border rounded-lg p-4 mb-6">
        <canvas
          ref={canvasRef}
          width={CANVAS_SIZE}
          height={CANVAS_SIZE}
          className="bg-dark-secondary rounded"
        />
      </div>

      {gameState.gameOver && (
        <div className="text-center mb-4">
          <p className="text-red-400 font-bold text-xl">Game Over!</p>
          <p className="text-gray-400">Final Score: {gameState.score}</p>
        </div>
      )}

      <div className="flex space-x-4">
        <button onClick={startGame} className="btn-neon px-6 py-3 rounded-lg">
          {gameState.gameRunning ? "Restart Game" : "Start Game"}
        </button>
        <button
          onClick={() => setLocation("/")}
          className="border border-gray-500 px-6 py-3 rounded-lg font-orbitron text-white hover:border-neon-blue transition-colors"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}
